﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOver : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnGUI() {
	 if (GUI.Button(new Rect(100, 70, 250, 50), "Thanks for playing. Game is over."))
            Application.LoadLevel(1);
        }


}
