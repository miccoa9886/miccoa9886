﻿using UnityEngine;
using System.Collections;

public class m2mm2 : MonoBehaviour {

	private Transform target;
	private float speed = 10f;
	private Vector3 speedRot = Vector3.right * 50f;
	public float delta = 5.5f;  // Amount to move left and right from the start point

	private Vector3 startPos;
	void Start () {
		target = GameObject.FindGameObjectWithTag("Player").transform;
		Debug.Log (target.name);
		startPos = transform.position;
	}

	void Update ()
	{
		if (GameObject.Find ("BarTop2") != null) {
			//transform.Rotate (speedRot * Time.deltaTime);
			transform.position = Vector3.MoveTowards (transform.position, target.position, speed * Time.deltaTime);

			Vector3 v = startPos;
			v.x += delta * Mathf.Sin (Time.time * speed);
			//transform.position = v;
		} else {
			Destroy (this.gameObject, 10);
		}

		if (Input.GetKeyDown(KeyCode.F)){
			Application.LoadLevel (0);
		}



	}
}

