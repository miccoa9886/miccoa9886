﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BlockScript : MonoBehaviour {
	public static int mjm2j2m;
	public int hitsToKill;
	public int points;
	private int numberOfHits;
	private Vector2 liikettaobjektia;
		public Object particleSystems; 
		public Object ps;
	public ParticleSystem ps0;
	public newlevelm npoints;
	public int playerPoints;
	public Object m2m2m; 

		void Awake(){
				particleSystems = Resources.Load ("Explosions/Explosion07", typeof(GameObject));
				ps = Resources.Load ("Explosions/Explosion02", typeof(GameObject));

				//particleSystems02020 = Resources.Load ("Flares/Flare03-Autumn", typeof(GameObject));

		m2m2m = Resources.Load("Explosions/Explosion05", typeof(GameObject));
	}




	IEnumerator jotain20om() {
		
		//print (Time.time);
		yield return new WaitForSeconds(1);
		//Application.LoadLevel (0);
		//print ("moromoro");
	}

	IEnumerator jotain23k() {
		yield return new WaitForSeconds (2);
		//print ("moromoro20m");
	}

	// Use this for initialization
	void Start () {
		mjm2j2m = 0;
		//Debug.Log ("lisääsli0923493242");  print ("moi");
		numberOfHits = 0;
		liikettaobjektia = new Vector2 (20.0f,0.0f);
				//GameObject go02020 = Instantiate (ps, Vector3.zero, Quaternion.identity) as GameObject;
				//Destroy (go02020, 2f);
				//GameObject go02020 = Instantiate (particleSystems, Vector3.zero, Quaternion.identity) as GameObject;
				//Destroy (go02020, 10);
		PlayerPrefs.SetInt ("Score", 0);

		
	}

	
	// Update is called once per frame
	void Update () {
				GetComponent<Rigidbody2D>().isKinematic = false;

				// add a force
				GetComponent<Rigidbody2D>().AddForce(liikettaobjektia);
		if (transform.position.y < -9) {
			//Destroy (this.gameObject, 0.1f);
		}

	}
	void addPoints(int points){
		playerPoints += points;
	}

	void OnGUI(){
		GUI.Label (new Rect (425.0f, 30.0f, 200.0f, 200.0f), "  Score: " + playerPoints);
	}

	void OnCollisionEnter2D(Collision2D collision){
		//bool test2=false;
		if (collision.gameObject.tag == "Ball") {
			numberOfHits++;
			//Debug.Log ("peliojekti nim" + this.gameObject);


				
				mjm2j2m = mjm2j2m + 1;
				//Debug.Log ("lisääsli0923493242");
				//Debug.Log (mjm2j2m);
				//GameObject ps = particleSystem.name;
				//GameObject go = Instantiate (particleSystems, Vector3.zero, Quaternion.identity) as GameObject;
				//Destroy (go, 10);
			//if (GameObject.Find(" " + this.gameObject + " ") != null) {
				//test2 = true;
			
				//if (test2 == true) {
			ps0.Play ();
			playerPoints = playerPoints + 50;
			Destroy (this.gameObject, 1f);
				//}
			//}
			if (mjm2j2m == 2) {
				//Debug.Log ("2moipitäsloadaa");
				//Debug.Log (Application.loadedLevelName);
				if (Application.loadedLevelName.Equals ("Level1")) {
					//StartCoroutine (TestCoroutine ());
				}
			}
			if (mjm2j2m == 3) { // dmfsjdkmfkdsmkd.mdkmfkd.mdfkd,fmkdmfkd,.fmkdfkdfmmdfk,"'-.l,l.,lmdfkdmdfkds
				if (Application.loadedLevelName.Equals ("level.2")) {

					//StartCoroutine (jotain23k ());
					//StartCoroutine (jotain20om ());
				}

				//GameObject g22435m2 = Instantiate (m2m2m, Vector3.zero, Quaternion.identity) as GameObject;
				//Destroy (g22435m2, 2f); 
				//mjm2j2m = 0;


			}
			if (mjm2j2m == 4) {
				//Debug.Log ("2moipitäsloadaa");
				//Debug.Log (Application.loadedLevelName);
				if (Application.loadedLevelName.Equals ("lev4")) {
					//StartCoroutine (TestCoroutine ());
				}
				mjm2j2m = 0;
			}


		} 

			if (numberOfHits == hitsToKill){

				// get reference of player object
				GameObject player = GameObject.FindGameObjectsWithTag("Player")[0];

				// send message
				player.SendMessage("addPoints", points);
				PlayerPrefs.SetInt("Player Score", points);

					PlayerPrefs.SetInt("Score", PlayerPrefs.GetInt("Score")+10);

				// destroy the object
				Destroy(this.gameObject);
			}
		
				if (collision.gameObject.tag == "Baroikea") {
						liikettaobjektia = new Vector2 (-27.0f,2.0f);
						//print ("moro");
				}
				if (collision.gameObject.tag == "Vasen") {
						liikettaobjektia = new Vector2 (20.0f,0.0f);
				}
				//
	}
	void Example() {
		
		//Application.LoadLevel (0);
	}

	

}
