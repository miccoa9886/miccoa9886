﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ForkandBeard.Util.Geometry
{
    public enum LociType
    {
        Empty = 0
        , Line = 1
        , Rectangle = 2
        , Point = 3
    }
}
