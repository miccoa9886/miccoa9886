﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ForkandBeard.Logic.BAL.Enums
{
    public enum Directory
    {
        Connection_Strings = 0
    }
}
