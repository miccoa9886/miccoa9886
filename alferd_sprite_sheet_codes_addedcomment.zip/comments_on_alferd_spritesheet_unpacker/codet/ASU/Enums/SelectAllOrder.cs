﻿namespace ASU.Enums
{
    public enum SelectAllOrder
    {
        TopLeft = 0
        , BottomLeft = 1
        , Centre = 2
    }
}