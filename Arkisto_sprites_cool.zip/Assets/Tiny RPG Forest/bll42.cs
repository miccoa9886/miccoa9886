using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class bll42 : MonoBehaviour
{
    public Text myText;
    public static int scores;
    private int i;
    private GameObject tesmo;
    private GameObject tesmo2;
    // Start is called before the first frame update
    void Start()
    {
        myText.text ="This is my text";
        //Mytext = GetComponent<Text>();
        //Mytext.text = "Score: " + 100;
    }

    // Update is called once per frame
    

        void OnTriggerEnter2D(Collider2D col)
    {

        //scores = scores + 1000;
          //  myText.text = "Scores: " + scores;

        if(col.gameObject.tag.Equals("RussiaTnks020202")){
            
            scores = scores + 10;
            //myText.text = "Yo!";
            //tesmo2 = GameObject.Find("Mytext222");
            //tesmo2.text = "Tervee!";
            Debug.Log("scores " + scores);
            //myText.text = "Scores: 1000";
            Debug.Log("Playa242");
            
            //Destroy(gameObject);
            tesmo = GameObject.Find("sdf");
            Destroy(tesmo);
            //scores = scores + 1000;
            //myText.text = "Scores: 1000";
        //Destroy(playa222);

        }
          if(col.gameObject.tag.Equals("RessienTonks99")){
            
            
            scores = scores + 10;
            Debug.Log("scores " + scores);
            //myText.text = "Scores: 1000";
            Debug.Log("Playa242");
           
            //Destroy(gameObject);
            tesmo2 = GameObject.Find("sdf_2");
            Destroy(tesmo2);
            //scores = scores + 1000;
            //Mytext.text = "Scores: " + scores;
        //Destroy(playa222);

        }
    }

    void Update()
    {   
        i = i + 1;
        //scores = scores + i;
        myText.text = "Scores: " + scores;//+ i;
        
    }

     void OnGUI() {
        GUI.Label(new Rect(10, 10, 500, 20), "Hello. Scores are here " + scores);
    }
}
