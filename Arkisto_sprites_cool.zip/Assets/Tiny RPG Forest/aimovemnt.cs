using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class aimovemnt : MonoBehaviour
{
    
    Vector3 startPosition;
    // Start is called before the first frame update
    void Start()
    {
         startPosition = this.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = startPosition + Vector3.up * Mathf.Sin(Time.realtimeSinceStartup) * 5f;
    }
}
