﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueBlockEspaceRoute : MonoBehaviour {
		public float speedi = 0.5f;
		public float speed = 3.5f;
		Vector2 positionToMoveTo = new Vector2(200.0f, 4.0f);
		Vector2 startPos = new Vector2(0.0f, 0.0f);

	// Use this for initialization
	void Start () {
				Vector2 startPos = transform.position;
				Vector2 positionToMoveTo2 = startPos;
	}
	
	// Update is called once per frame
	void Update () {
				
				//if (transform.position == positionToMoveTo) {
						transform.position = Vector2.MoveTowards(transform.position, positionToMoveTo, speed * Time.deltaTime);
				//}

		//transform.position = new Vector2(transform.position.x+speedi, transform.position.y);
				transform.position = Vector2.MoveTowards(transform.position, startPos, speed * Time.deltaTime);
	}
}
