﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueBlockEspaceRoute : MonoBehaviour {
		public float speedi = 0.5f;
		public float speed = 0.5f;
		private float rangeX = 2f;

 //Up at the top with your variables:
 private Vector3 dir = Vector3.left;


		Vector2 positionToMoveTo = new Vector2(200.0f, 4.0f);
		Vector2 startPos = new Vector2(0.0f, 0.0f);

	// Use this for initialization
	void Start () {
				Vector2 startPos = transform.position;
				Vector2 positionToMoveTo2 = startPos;
	}
	
	// Update is called once per frame
	void Update () {
				
				//if (transform.position == positionToMoveTo) {
						//transform.position = Vector2.MoveTowards(transform.position, positionToMoveTo, speed * Time.deltaTime);
				//}

				//if (transform.position.x >= 10 ) {
						//transform.position = new Vector2 (transform.position.x + speedi, transform.position.y);

				//}

				//if (transform.position.x <= 10.1)

				//{
				//		transform.Translate(Vector3.right * speedi);

						//transform.position = new Vector2 (transform.position.x + speedi, transform.position.y);;

				//}
				//if (transform.position.x > 10) {
						//transform.position = new Vector2 (transform.position.y + speedi, transform.position.y);;
//transform.Translate(Vector3.left * speedi);

//				}

				      transform.Translate(dir*speed);
 
      if(transform.position.x <= -15){
           dir = Vector3.right;
      }else if(transform.position.x >= 15){
           dir = Vector3.left;
      }


				//transform.position = Vector2.MoveTowards(transform.position, startPos, speed * Time.deltaTime);
	

				//transform.Translate(Vector3.forward * Time.deltaTime * speed);
				// transform.Translate(Vector3.left * Time.deltaTime * speed); // delete this line if you want to go straight down

			
				/*if (transform.position.x > rangeX)

				{
						transform.Translate(Vector3.right * Time.deltaTime * speed);
				}*/


		}
}
